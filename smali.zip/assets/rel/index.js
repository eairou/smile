
s = {
  "en" : {
    title:"New Features",
    version:"Version",
    rel:{
      "1.8.4":[
        "One tap play/pause instead of double tap (Please turn it on in the settings.)",
        "rel_108_settings.jpg",
        "You can disable on-screen volume/brightness control in the settings.",
        "Auto Landscape mode is off by default."
      ],
      "1.8":[
        "Support audio file",
        "rel_108_audio.jpg",
        "Play button customization (position, size, margin)",
        "rel_108_fab.jpg",
        "Auto-rewind customization (2~4 seconds before)",
        "Fix TED download in Android 11",
        "Auto Landscape mode in fullscreen mode (Optional)"
      ],
      "1.7":[
        "Support Dark theme",
        "rel_107_darktheme.jpg",
        "Support more dictionaries - Google, WordReference, Wikionary, Yandex, Cambridge, Oxford, Naver",
        "rel_107_dictsel.jpg",
        "Fix some errors - notification media controller, dictionary, file browser, etc.",
      ],
      "1.6":[
        "Improved dictionary feature (Automatic Search)",
        "rel_106_dicview.png",
        "Customizable subtitle color and size",
        "Customizable background opacity",
        "rel_106_css.jpg",
      ]
    }
  },
  "am": {
    "title": "አዳዲስ ባህሪያት",
    "version": "እትም",
    "rel": {
        "1.8.4": [
            "አንዳንድ ግርጌ መቆጣጠሪ የሚችል ሞድ/ሰንሰር ብርሃን (በቅንብሮች ውስጥ መክፈት ይኖርብዎታል።)",
            "rel_108_settings.jpg",
            "በማእከል የድምፅ/የብርሀን መቆንቆኑን በቅንብሮች ማሰናከያ ይችላሉ።",
            "በነባሪ ሁኔታ የራስተኛ ላንድስኬፕ ሞድ ጠፍቷል።"
        ],
        "1.8": [
            "የድምፅ ፋይል መደገፍ",
            "rel_108_audio.jpg",
            "የአንድን ቀንድ ማለፊያ (ቦታ፣ መጠን፣ ወሬድ)",
            "rel_108_fab.jpg",
            "በፊት 2~4 ሰከንዶች ያተኮረ መተንፈሻ",
            "በእንድሮይድ 11 ላይ TED መጫን ችግርን ማስተካከል",
            "በሙሉ ማያ ሞድ ራስተኛ ላንድስኬፕ ሞድ (አማራጭ)"
        ],
        "1.7": [
            "የጨለማ ቲም መደገፍ",
            "rel_107_darktheme.jpg",
            "ተጨማሪ መዝገቦችን መደገፍ - Google, WordReference, Wikionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "አንዳንድ ስህተቶችን መጠገን - ማሳወቂያ ሚዲያ ቁጥጥር፣ መዝገብ፣ ፋይል ቅበዘበዛ፣ ልዩነትና ተጨማሪዎች።"
        ],
        "1.6": [
            "የተሻሻለ መዝገበ ቃላት ባህሪ (ራስ-ተመን ፍለጋ)",
            "rel_106_dicview.png",
            "የሚቀየር የንግግር ቅርጸት እና መጠን",
            "የበስተጀርባ እንክብካቤ ግምት",
            "rel_106_css.jpg"
        ]
    }
  },
  "ar": {
    "title": "ميزات جديدة",
    "version": "الإصدار",
    "rel": {
        "1.8.4": [
            "تشغيل/إيقاف تشغيل باللمسة الواحدة بدلاً من النقر المزدوج (يرجى تشغيله في الإعدادات.)",
            "rel_108_settings.jpg",
            "يمكنك تعطيل التحكم في مستوى الصوت/السطوع على الشاشة في الإعدادات.",
            "وضع الشاشة التلقائي في وضع التصفح معطل افتراضيًا."
        ],
        "1.8": [
            "دعم ملف صوتي",
            "rel_108_audio.jpg",
            "تخصيص زر التشغيل (الموضع، الحجم، الهامش)",
            "rel_108_fab.jpg",
            "تخصيص الإرجاع التلقائي (2~4 ثوانٍ قبل)",
            "إصلاح تنزيل TED في Android 11",
            "وضع الشاشة التلقائي في وضع ملء الشاشة (اختياري)"
        ],
        "1.7": [
            "دعم السمة الداكنة",
            "rel_107_darktheme.jpg",
            "دعم المزيد من القواميس - Google، WordReference، Wiktionary، Yandex، Cambridge، Oxford، Naver",
            "rel_107_dictsel.jpg",
            "إصلاح بعض الأخطاء - وحدة التحكم في الوسائط التنبيهية، القاموس، مستعرض الملفات، الخ."
        ],
        "1.6": [
            "تحسين ميزة القاموس (البحث التلقائي)",
            "rel_106_dicview.png",
            "لون وحجم الترجمة قابلة للتخصيص",
            "تعتيم الخلفية قابل للتخصيص",
            "rel_106_css.jpg"
        ]
    }
  },
  "cs": {
    "title": "Nové funkce",
    "version": "Verze",
    "rel": {
        "1.8.4": [
            "Jednodotykové přehrání/pauza místo dvoukliku (Prosím, zapněte to v nastavení.)",
            "rel_108_settings.jpg",
            "Můžete vypnout ovládání hlasitosti/jasu na obrazovce v nastavení.",
            "Automatický režim automatického režimu je výchozím stavem vypnutý."
        ],
        "1.8": [
            "Podpora zvukového souboru",
            "rel_108_audio.jpg",
            "Přizpůsobení tlačítka přehrávání (pozice, velikost, okraj)",
            "rel_108_fab.jpg",
            "Přizpůsobení automatického přetočení (2~4 sekundy před)",
            "Oprava stahování TED v Androidu 11",
            "Automatický režim automatického režimu v režimu celé obrazovky (Volitelné)"
        ],
        "1.7": [
            "Podpora tmavého režimu",
            "rel_107_darktheme.jpg",
            "Podpora více slovníků - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "Oprava některých chyb - ovladač média v oznámení, slovník, prohlížeč souborů, atd."
        ],
        "1.6": [
            "Vylepšená funkce slovníku (Automatické vyhledávání)",
            "rel_106_dicview.png",
            "Přizpůsobitelná barva a velikost titulků",
            "Přizpůsobitelná průhlednost pozadí",
            "rel_106_css.jpg"
        ]
    }
},
"de": {
    "title": "Neue Funktionen",
    "version": "Version",
    "rel": {
        "1.8.4": [
            "Einzelne Berührung zur Wiedergabe/Pause anstelle von Doppelklick (Bitte aktivieren Sie dies in den Einstellungen.)",
            "rel_108_settings.jpg",
            "Sie können die Lautstärke/Helligkeit auf dem Bildschirm in den Einstellungen deaktivieren.",
            "Der Auto-Querformatmodus ist standardmäßig deaktiviert."
        ],
        "1.8": [
            "Unterstützung für Audiodatei",
            "rel_108_audio.jpg",
            "Anpassung der Wiedergabetaste (Position, Größe, Rand)",
            "rel_108_fab.jpg",
            "Anpassung der automatischen Rückspulfunktion (2~4 Sekunden vorher)",
            "Behebung des TED-Downloads in Android 11",
            "Auto-Querformatmodus im Vollbildmodus (Optional)"
        ],
        "1.7": [
            "Unterstützung des Dunkelmodus",
            "rel_107_darktheme.jpg",
            "Unterstützung von mehreren Wörterbüchern - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "Behebung einiger Fehler - Benachrichtigungs-Mediencontroller, Wörterbuch, Dateibrowser, etc."
        ],
        "1.6": [
            "Verbesserte Funktion des Wörterbuchs (Automatische Suche)",
            "rel_106_dicview.png",
            "Anpassbare Farbe und Größe der Untertitel",
            "Anpassbare Hintergrundopazität",
            "rel_106_css.jpg"
        ]
    }
  },
  "el": {
    "title": "Νέα χαρακτηριστικά",  // New Features (translated to Greek)
    "version": "Έκδοση",        // Version (translated to Greek)
    "rel": {
      "1.8.4": [
        "Αναπαραγωγή/παύση με ένα πάτημα σε οριζόντιο προσανατολισμό (Ενεργοποιήστε το στις ρυθμίσεις.)",  // One tap play/pause... (translated to Greek)
        "rel_108_settings.jpg",
        "Μπορείτε να απενεργοποιήσετε τον έλεγχο έντασης ή φωτεινότητας στην οθόνη στις ρυθμίσεις.",  // You can disable... (translated to Greek)
        "Η αυτόματη οριζόντια λειτουργία είναι απενεργοποιημένη από προεπιλογή."  // Auto Landscape... (translated to Greek)
      ],
      "1.8": [
        "Υποστήριξη αρχείων ήχου",
        "rel_108_audio.jpg",
        "Προσαρμογή κουμπιού αναπαραγωγής (θέση, μέγεθος, περιθώριο)",
        "rel_108_fab.jpg",
        "Προσαρμογή αυτόματης επανατυλίξεως (2~4 δευτερόλεπτα πριν)",
        "Διόρθωση προβλήματος λήψης TED στο Android 11",
        "Αυτόματη οριζόντια λειτουργία σε λειτουργία πλήρους οθόνης (προαιρετικό)"
      ],
      "1.7": [
        "Υποστήριξη σκοτεινού θέματος",
        "rel_107_darktheme.jpg",
        "Υποστήριξη περισσότερων λεξικών - Google, WordReference, Wikionary, Yandex, Cambridge, Oxford, Naver",
        "rel_107_dictsel.jpg",
        "Διόρθωση ορισμένων σφαλμάτων - Ελεγκτής μέσων ειδοποιήσεων, λεξικό, διαχειριστής αρχείων κ.λπ."
      ],
      "1.6": [
        "Βελτιωμένη λειτουργία λεξικού (Αυτόματη αναζήτηση)",
        "rel_106_dicview.png",
        "Προσαρμόσιμος χρωματισμός και μέγεθος υπότιτλων",
        "Προσαρμόσιμη διαφάνεια φόντου",
        "rel_106_css.jpg"
      ]
    }
  },
  "fa": {
    "title": "امکانات جدید",  // New Features (translated to Farsi)
    "version": "نسخه",        // Version (translated to Farsi)
    "rel": {
      "1.8.4": [
        "با یک ضربه در حالت افقی پخش/توقف کنید (لطفاً آن را در تنظیمات روشن کنید)",  // One tap play/pause... (translated to Farsi)
        "rel_108_settings.jpg",
        "می‌توانید کنترل‌های صدا/روشنایی روی صفحه را در تنظیمات غیرفعال کنید",  // You can disable... (translated to Farsi)
        "حالت افقی خودکار به طور پیش فرض خاموش است"  // Auto Landscape... (translated to Farsi)
      ],
      "1.8": [
        "پشتیبانی از فایل صوتی",
        "rel_108_audio.jpg",
        "شخصی سازی دکمه پخش (موقعیت، اندازه، حاشیه)",
        "rel_108_fab.jpg",
        "شخصی سازی بازگشت خودکار (2~4 ثانیه قبل)",
        "رفع مشکل دانلود TED در اندروید 11",
        "حالت افقی خودکار در حالت تمام صفحه (اختیاری)"
      ],
      "1.7": [
        "پشتیبانی از تم تیره",
        "rel_107_darktheme.jpg",
        "پشتیبانی از دیکشنری‌های بیشتر - Google، WordReference، Wikionary، Yandex، Cambridge، Oxford، Naver",
        "rel_107_dictsel.jpg",
        "رفع برخی از باگ‌ها - کنترل‌کننده رسانه اعلان، دیکشنری، مرورگر فایل و غیره"
      ],
      "1.6": [
        "ویژگی بهبود یافته دیکشنری (جست خودکار)",
        "rel_106_dicview.png",
        "رنگ و اندازه زیرنویس قابل تنظیم",
        "شفافیت پس‌زمینه قابل تنظیم",
        "rel_106_css.jpg"
      ]
    }
  },
  "fr": {
    "title": "Nouvelles fonctionnalités",  // New Features (translated to French)
    "version": "Version",        // Version (no translation needed)
    "rel": {
      "1.8.4": [
        "Lecture/pause en une touche en mode paysage (Activez-le dans les paramètres.)",  // One tap play/pause... (translated to French)
        "rel_108_settings.jpg",
        "Vous pouvez désactiver le contrôle du volume/de la luminosité à l'écran dans les paramètres.",  // You can disable... (translated to French)
        "Le mode paysage automatique est désactivé par défaut."  // Auto Landscape... (translated to French)
      ],
      "1.8": [
        "Prise en charge des fichiers audio",
        "rel_108_audio.jpg",
        "Personnalisation du bouton de lecture (position, taille, marge)",
        "rel_108_fab.jpg",
        "Personnalisation du rembobinage automatique (2 à 4 secondes avant)",
        "Correction du problème de téléchargement TED sous Android 11",
        "Mode paysage automatique en plein écran (facultatif)"
      ],
      "1.7": [
        "Prise en charge du thème sombre",
        "rel_107_darktheme.jpg",
        "Prise en charge de plus de dictionnaires - Google, WordReference, Wikionary, Yandex, Cambridge, Oxford, Naver",
        "rel_107_dictsel.jpg",
        "Correction de quelques bugs - Contrôle des médias de notification, dictionnaire, explorateur de fichiers, etc."
      ],
      "1.6": [
        "Fonctionnalité de dictionnaire améliorée (recherche automatique)",
        "rel_106_dicview.png",
        "Couleur et taille personnalisables des sous-titres",
        "Opacité d'arrière-plan personnalisable",
        "rel_106_css.jpg"
      ]
    }
  },
  "hi": {
    "title": "नए विशेषताएँ",
    "version": "संस्करण",
    "rel": {
        "1.8.4": [
            "दो टैप के बजाय एक टैप में प्ले/पॉज़ करें (कृपया इसे सेटिंग्स में सक्षम करें।)",
        "rel_108_settings.jpg",
            "आप सेटिंग्स में स्क्रीन पर वॉल्यूम/चमक के नियंत्रण को अक्षम कर सकते हैं।",
            "ऑटो लैंडस्केप मोड डिफ़ॉल्ट रूप से बंद है।"
        ],
        "1.8": [
            "ऑडियो फ़ाइल का समर्थन",
            "rel_108_audio.jpg",
            "प्ले बटन अनुकूलन (स्थान, आकार, मार्जिन)",
            "rel_108_fab.jpg",
            "स्वचालित पुनःअनुक्रमण (2~4 सेकंड पहले)",
            "Android 11 में TED डाउनलोड को ठीक करें",
            "पूर्ण स्क्रीन मोड में ऑटो लैंडस्केप मोड (वैकल्पिक)"
        ],
        "1.7": [
            "डार्क थीम का समर्थन",
            "rel_107_darktheme.jpg",
            "अधिक शब्दकोशों का समर्थन - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "कुछ त्रुटियों का सुधार - अधिसूचना मीडिया नियंत्रक, शब्दकोश, फ़ाइल ब्राउज़र, आदि।"
        ],
        "1.6": [
            "शब्दकोश सुधार (स्वचालित खोज)",
            "rel_106_dicview.png",
            "स्थिति और आकार अनुकूलित उपशीर्षक रंग",
            "पृष्ठभूमि की अपारदर्शिता अनुकूलित करें",
            "rel_106_css.jpg"
        ]
    }
},
"hu": {
    "title": "Újdonságok",
    "version": "Verzió",
    "rel": {
        "1.8.4": [
            "Egy érintéses lejátszás/szüneteltetés helyett dupla érintés (Kérjük, kapcsolja be a beállításokban.)",
        "rel_108_settings.jpg",
            "Kikapcsolhatja a képernyőn megjelenő hangerő/fényerő vezérlését a beállításokban.",
            "Az automata tájkép mód alapértelmezett módon ki van kapcsolva."
        ],
        "1.8": [
            "Hangfájl támogatása",
            "rel_108_audio.jpg",
            "Lejátszó gomb testreszabása (pozíció, méret, margó)",
            "rel_108_fab.jpg",
            "Automatikus visszatekerés testreszabása (2~4 másodperccel korábban)",
            "TED letöltés javítása Android 11-en",
            "Automata tájkép mód teljes képernyős módban (Opcionális)"
        ],
        "1.7": [
            "Sötét téma támogatása",
            "rel_107_darktheme.jpg",
            "Több szótár támogatása - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "Néhány hiba javítása - értesítési média vezérlő, szótár, fájlkezelő, stb."
        ],
        "1.6": [
            "Szótár funkció javítása (Automatikus keresés)",
            "rel_106_dicview.png",
            "Felirat színének és méretének testreszabása",
            "Háttér opacitásának testreszabása",
            "rel_106_css.jpg"
        ]
    }
  },
  "in": {
    "title": "Fitur Baru",
    "version": "Versi",
    "rel": {
        "1.8.4": [
            "Main/Pause satu ketukan daripada dua ketukan (Mohon aktifkan di pengaturan.)",
        "rel_108_settings.jpg",
            "Anda dapat menonaktifkan kontrol volume/kecerahan layar di pengaturan.",
            "Mode Lanskap Otomatis dinonaktifkan secara default."
        ],
        "1.8": [
            "Dukungan file audio",
            "rel_108_audio.jpg",
            "Penyesuaian tombol putar (posisi, ukuran, margin)",
            "rel_108_fab.jpg",
            "Penyesuaian putar mundur otomatis (2~4 detik sebelumnya)",
            "Perbaikan unduhan TED di Android 11",
            "Mode Lanskap Otomatis dalam mode layar penuh (Opsional)"
        ],
        "1.7": [
            "Dukungan tema Gelap",
            "rel_107_darktheme.jpg",
            "Dukungan lebih banyak kamus - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "Perbaikan beberapa kesalahan - pengontrol media notifikasi, kamus, penjelajah file, dll."
        ],
        "1.6": [
            "Peningkatan fitur kamus (Pencarian Otomatis)",
            "rel_106_dicview.png",
            "Warna dan ukuran teks subtitel yang dapat disesuaikan",
            "Opasitas latar belakang yang dapat disesuaikan",
            "rel_106_css.jpg"
        ]
    }
},
"it": {
    "title": "Nuove Funzionalità",
    "version": "Versione",
    "rel": {
        "1.8.4": [
            "Riproduzione/Pausa con un solo tocco invece di doppio tocco (Si prega di attivarlo nelle impostazioni.)",
        "rel_108_settings.jpg",
            "È possibile disabilitare il controllo del volume/luminosità sullo schermo nelle impostazioni.",
            "La modalità Paesaggio automatico è disattivata per impostazione predefinita."
        ],
        "1.8": [
            "Supporto file audio",
            "rel_108_audio.jpg",
            "Personalizzazione del pulsante Riproduci (posizione, dimensione, margine)",
            "rel_108_fab.jpg",
            "Personalizzazione del riavvolgimento automatico (2~4 secondi prima)",
            "Correzione del download TED in Android 11",
            "Modalità Paesaggio automatico in modalità schermo intero (Opzionale)"
        ],
        "1.7": [
            "Supporto Tema Scuro",
            "rel_107_darktheme.jpg",
            "Supporto a più dizionari - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "Correzione di alcuni errori - controller multimediale delle notifiche, dizionario, browser di file, ecc."
        ],
        "1.6": [
            "Miglioramento della funzione del dizionario (Ricerca Automatica)",
            "rel_106_dicview.png",
            "Colore e dimensione dei sottotitoli personalizzabili",
            "Opacità dello sfondo personalizzabile",
            "rel_106_css.jpg"
        ]
    }
  },
  "ja": {
    "title": "新機能",
    "version": "バージョン",
    "rel": {
        "1.8.4": [
            "ダブルタップの代わりにワンタップで再生/一時停止 (設定で有効にしてください)",
        "rel_108_settings.jpg",
            "設定で画面上の音量/明るさコントロールを無効にできます",
            "デフォルトではオートランドスケープモードはオフになっています"
        ],
        "1.8": [
            "オーディオファイルのサポート",
            "rel_108_audio.jpg",
            "再生ボタンのカスタマイズ (位置、サイズ、マージン)",
            "rel_108_fab.jpg",
            "自動巻き戻しのカスタマイズ (2~4秒前)",
            "Android 11 での TED のダウンロードの修正",
            "全画面モードでのオートランドスケープモード (オプション)"
        ],
        "1.7": [
            "ダークテーマのサポート",
            "rel_107_darktheme.jpg",
            "より多くの辞書のサポート - Google、WordReference、Wiktionary、Yandex、Cambridge、Oxford、Naver",
            "rel_107_dictsel.jpg",
            "いくつかのエラーの修正 - 通知メディアコントローラ、辞書、ファイルブラウザなど"
        ],
        "1.6": [
            "辞書機能の改善 (自動検索)",
            "rel_106_dicview.png",
            "サブタイトルの色とサイズのカスタマイズ",
            "背景の不透明度のカスタマイズ",
            "rel_106_css.jpg"
        ]
    }
  },
  "km": {
    "title": "លក្ខណៈ​ថ្មី",
    "version": "កំណែ",
    "rel": {
        "1.8.4": [
            "ចុចមួយដោយកំុព្យសម្បត្តិករស៊ីប៉ូតទេព៌តក្នុងការបើក/ផ្អាកប្រតិកម្ម (សូមបើកវានៅក្នុងការកំណត់។)",
        "rel_108_settings.jpg",
            "អ្នកអាចបិទបង្កាន់ដៃកំណត់កម្រិតសំឡេង/វគ្គបន្ថែមលើអេក្រង់ក្នុងការកំណត់។",
            "របៀបប្រើប្រាស់តាមលោកអ្នកទៅជាលំនាំដើមស្របរបស់ការបើក/បិទប្រតិកម្មរបស់លោកអ្នក។"
        ],
        "1.8": [
            "ការគាំទ្រឯកសារអូឌីយ៉ុង",
            "rel_108_audio.jpg",
            "ការផ្លាស់ប្ដូរប៊ូតុងការចាក់ (ទីតាំង, ទំហំ, មាន)",
            "rel_108_fab.jpg",
            "ការផ្លាស់ប្ដូរដំណើរការថ្មីបំផុត (2~4 វិនាទីមុន)",
            "កំណត់ការទាញ TED កុំព្យូទ័រនៅ Android 11",
            "របៀបរដូវប្រភេទអេក្រង់ដោយស្វ័យប្រវត្តិ (ជម្រើស)"
        ],
        "1.7": [
            "ការគាំទ្រប្រអប់ច្រលប់",
            "rel_107_darktheme.jpg",
            "ការគាំទ្របីពាក្យវាយតាមចំណាត់ថ្នាក់ច្រើន - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "កំណត់កំហុសនៃការរដ្ឋបាល - កម្មវិធីគ្រប់គ្រងប្រព័ន្ធ, វចនានុក្រម, ទីតាំងឯកសារ, ជាវៀង។"
        ]
    }
  },
  "ko": {
    "title": "새로운 기능",  // New Features (translated to Korean)
    "version": "버전",        // Version (translated to Korean)
    "rel": {
      "1.8.4": [
        "더블 탭 대신 한 번 탭으로 재생/정지 (설정에서 켜세요)",  // One tap play/pause... (translated to Korean, clearer)
        "rel_108_settings.jpg",
        "화면에서 볼륨/밝기 조절 끄기 (설정)",  // You can disable... (translated to Korean, clearer)
        "자동 가로 모드 기본 꺼짐",  // Auto Landscape mode... (translated to Korean, clearer)
      ],
      "1.8": [
        "오디오 파일 지원",
        "rel_108_audio.jpg",
        "재생 버튼 사용자 정의 (위치, 크기, 여백)",
        "rel_108_fab.jpg",
        "자동 되감기 사용자 정의 (2~4초 전)",
        "Android 11에서 TED 다운로드 수정",
        "전체 화면 모드에서 자동 가로 모드 (선택 사항)"
      ],
      "1.7": [
        "다크 테마 지원",
        "rel_107_darktheme.jpg",
        "더 많은 사전 지원 - Google, WordReference, Wikionary, Yandex, Cambridge, Oxford, Naver",
        "rel_107_dictsel.jpg",
        "몇 가지 버그 수정 - 알림 미디어 컨트롤러, 사전, 파일 브라우저 등"
      ],
      "1.6": [
        "개선된 사전 기능 (자동 검색)",
        "rel_106_dicview.png",
        "사용자 정의 가능한 자막 색상 및 크기",
        "사용자 정의 가능한 배경 불투명도",
        "rel_106_css.jpg"
      ]
    }
  },
  "ml": {
    "title": "പുതിയ സവിശേഷങ്ങൾ",
    "version": "പതിപ്പ്",
    "rel": {
        "1.8.4": [
            "സെറ്റിംഗുകളിൽ നിന്നും ഓൺ ചെയ്യുക, ഡബിൾ ടാപ്പ് പ്ലേ/പോസ് ബട്ടൺ കിട്ടുന്നതിന് (ദയവായി സെറ്റിങ്ങുകൾ ഓൺ ചെയ്യുക.)",
        "rel_108_settings.jpg",
            "സെറ്റിങ്ങുകളിൽ സ്ക്രീൻ മുകളിൽ വോള്യൂം/തെളിവ് നിയന്ത്രണം അക്ഷമമാക്കിയാൽ.",
            "ഡിഫോൾട് ആയി ഓട്ടോ ലാൻഡ്‌സ്കേപ് മോഡ് ഓഫ് ആണ്."
        ],
        "1.8": [
            "ഓഡിയോ ഫയൽ പിന്തുണ",
            "rel_108_audio.jpg",
            "പ്ലേ ബട്ടൺ സജ്ജീകരണം (സ്ഥാനം, വലിപ്പം, അവലംബം)",
            "rel_108_fab.jpg",
            "സ്വയം അടക്കം കസ്റ്റമൈസേഷൻ (2~4 സെക്കൻഡ് മുൻനിരയിൽ)",
            "Android 11-ലെ TED ഡൗൺലോഡ് പരാജയപ്പെട്ടത് പരിഹരിക്കുക",
            "പൂർണ്ണ സ്ക്രീൻ മോഡിൽ ഓട്ടോ ലാൻഡ്‌സ്കേപ് മോഡ് (ഐച്ഛികം)"
        ],
        "1.7": [
            "ഇരുട്ട് തീം പിന്തുണ",
            "rel_107_darktheme.jpg",
            "കൂടുതൽ നിഘണ്ടുകൾ പിന്തുണ - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "ചില പിഴവുകൾ പരിഹരിക്കുക - അറിയിപ്പ് മീഡിയ നിയന്ത്രണം, നിഘണ്ടു, ഫയൽ ബ്രൌസർ, എന്നിവ."
        ],
        "1.6": [
            "നിങ്ങളുടെ ഫലം പരിശോധിച്ചു പെറ്റേണ്ടത് (ഓട്ടോമാറ്റിക് തിരച്ചുവഴി)",
            "rel_106_dicview.png",
            "കസ്റ്റമൈസേബിൾ ഉപശീര്ഷക നിറം വലിപ്പവും വലിപ്പവും",
            "കസ്റ്റമൈസേബിൾ പേരിൽ പുതിയ പുതിയ റിവൈന്റ് (2-4 സെക്കൻഡ് മുൻനിരയിൽ)"
        ]
    }
  },
  "mn": {
    "title": "Шинэ үзэгдлүүд",
    "version": "Хувилбар",
    "rel": {
        "1.8.4": [
            "Тохиргоос шалгаад суулгана уу. (Давхар товшилттайгаар аль хэдийн дагуу тоглож/зогсоо)",
        "rel_108_settings.jpg",
            "Тохиргоос шалгаад, дэлгэц дээрх дууны/гэрчлэлийн удирдлагыг идэвхжүүлж болно.",
            "Автомат хэвтээ мод нь анхны аргаар идэвхтэйгээр гарсан байна."
        ],
        "1.8": [
            "Одио файлыг дэмждэг",
            "rel_108_audio.jpg",
            "Тоглуулах товчийг зөвшөөрөх (байрлал, хэмжээ, гадна)",
            "rel_108_fab.jpg",
            "Автомат хойно хэвлэлтийг зөвшөөрөх (2~4 секундын өмнө)",
            "Android 11 дээр TED татаж авах алдааг засах",
            "Дэлгэц дээр автомат хэвтээ мод (Сонголттой)"
        ],
        "1.7": [
            "Сааралт төлөв дэмждэг",
            "rel_107_darktheme.jpg",
            "Илүү олон толь дэмждэг - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "Зөвлөмжүүдээс засварласан алдааг засах - мэдээллийн медиа контроллер, толь, файлын броузер зэрэг."
        ],
        "1.6": [
            "Дэлгэцний үгийг засах (Автоматаар Хайх)",
            "rel_106_dicview.png",
            "Субтитрын өнгөнийг болон хэмжээг засах",
            "Дэлгэцний дээд зургийн нягтаршааг засах",
            "rel_106_css.jpg"
        ]
    }
  },
  "ms": {
    "title": "Ciri-ciri Baru",
    "version": "Versi",
    "rel": {
        "1.8.4": [
            "Satu sentuhan main/jeda untuk Mod Lanskap (Sila hidupkan dalam tetapan.)",
        "rel_108_settings.jpg",
            "Anda boleh mematikan kawalan kecerahan / kelantangan skrin dalam tetapan.",
            "Mod Lanskap Auto dimatikan secara lalai."
        ],
        "1.8": [
            "Sokongan fail audio",
            "rel_108_audio.jpg",
            "Penyesuaian butang main (kedudukan, saiz, jarak)",
            "rel_108_fab.jpg",
            "Penyesuaian putaran automatik (2~4 saat sebelum)",
            "Betulkan muat turun TED di Android 11",
            "Mod Lanskap Auto dalam mod skrin penuh (Pilihan)"
        ],
        "1.7": [
            "Sokongan Tema Gelap",
            "rel_107_darktheme.jpg",
            "Sokongan lebih banyak kamus - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "Betulkan beberapa ralat - pengawal media pemberitahuan, kamus, penyemak imbas fail, dll.",
        ],
        "1.6": [
            "Ciri kamus yang Dipertingkatkan (Carian Automatik)",
            "rel_106_dicview.png",
            "Warna dan Saiz Subtitle yang Boleh disesuaikan",
            "Ketelusan Latar Belakang yang Boleh disesuaikan",
            "rel_106_css.jpg",
        ]
    }
  },
  "pl": {
    "title": "Nowe Funkcje",
    "version": "Wersja",
    "rel": {
        "1.8.4": [
            "Jedno dotknięcie odtwarzania/wstrzymywania w trybie pejzażowym (Należy to włączyć w ustawieniach.)",
        "rel_108_settings.jpg",
            "Możesz wyłączyć sterowanie głośnością/jasnością na ekranie w ustawieniach.",
            "Tryb pejzażowy Auto jest domyślnie wyłączony."
        ],
        "1.8": [
            "Obsługa plików audio",
            "rel_108_audio.jpg",
            "Dostosowanie przycisku odtwarzania (położenie, rozmiar, margines)",
            "rel_108_fab.jpg",
            "Dostosowanie automatycznego przewijania wstecz (2~4 sekundy wcześniej)",
            "Naprawa pobierania TED w Androidzie 11",
            "Tryb pejzażowy Auto w trybie pełnoekranowym (Opcjonalnie)"
        ],
        "1.7": [
            "Obsługa ciemnego motywu",
            "rel_107_darktheme.jpg",
            "Wsparcie dla większej liczby słowników - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "Naprawa kilku błędów - kontroler mediów powiadomień, słownik, przeglądarka plików, itp.",
        ],
        "1.6": [
            "Ulepszona funkcja słownika (Automatyczne wyszukiwanie)",
            "rel_106_dicview.png",
            "Dostosowywalny kolor i rozmiar napisów",
            "Dostosowywalna przezroczystość tła",
            "rel_106_css.jpg",
        ]
    }
  },
  "pt": {
    "title": "Novas Funcionalidades",
    "version": "Versão",
    "rel": {
        "1.8.4": [
            "Um toque para reproduzir/pausar no Modo Paisagem (Ative nas configurações.)",
        "rel_108_settings.jpg",
            "Você pode desativar o controle de volume/brilho na tela nas configurações.",
            "O Modo Paisagem Automático está desativado por padrão."
        ],
        "1.8": [
            "Suporte a arquivo de áudio",
            "rel_108_audio.jpg",
            "Personalização do botão de reprodução (posição, tamanho, margem)",
            "rel_108_fab.jpg",
            "Rebobinagem automática personalizável (2~4 segundos antes)",
            "Correção de download do TED no Android 11",
            "Modo Paisagem Automático no modo de tela cheia (Opcional)"
        ],
        "1.7": [
            "Suporte ao tema escuro",
            "rel_107_darktheme.jpg",
            "Suporte a mais dicionários - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "Correção de alguns erros - controlador de mídia de notificação, dicionário, navegador de arquivos, etc.",
        ],
        "1.6": [
            "Aprimoramento da funcionalidade de dicionário (Busca Automática)",
            "rel_106_dicview.png",
            "Cor e tamanho de legenda personalizáveis",
            "Opacidade de fundo personalizável",
            "rel_106_css.jpg",
        ]
    }
  },
  "pt": {
    "title": "Novas Funcionalidades",
    "version": "Versão",
    "rel": {
        "1.8.4": [
            "Um toque para reproduzir/pausar no Modo Paisagem (Ative nas configurações.)",
        "rel_108_settings.jpg",
            "Você pode desativar o controle de volume/brilho na tela nas configurações.",
            "O Modo Paisagem Automático está desativado por padrão."
        ],
        "1.8": [
            "Suporte a arquivo de áudio",
            "rel_108_audio.jpg",
            "Personalização do botão de reprodução (posição, tamanho, margem)",
            "rel_108_fab.jpg",
            "Rebobinagem automática personalizável (2~4 segundos antes)",
            "Correção de download do TED no Android 11",
            "Modo Paisagem Automático no modo de tela cheia (Opcional)"
        ],
        "1.7": [
            "Suporte ao tema escuro",
            "rel_107_darktheme.jpg",
            "Suporte a mais dicionários - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "Correção de alguns erros - controlador de mídia de notificação, dicionário, navegador de arquivos, etc.",
        ],
        "1.6": [
            "Aprimoramento da funcionalidade de dicionário (Busca Automática)",
            "rel_106_dicview.png",
            "Cor e tamanho de legenda personalizáveis",
            "Opacidade de fundo personalizável",
            "rel_106_css.jpg",
        ]
    }
  },
  "sk": {
    "title": "Nové funkcie",
    "version": "Verzia",
    "rel": {
        "1.8.4": [
            "Jedno dotknutie prehrávania/zastavenia v režime na šírku (Prosím, zapnite to v nastaveniach.)",
        "rel_108_settings.jpg",
            "Môžete zakázať ovládanie hlasitosti/jasu na obrazovke v nastaveniach.",
            "Automatický režim na šírku je predvolene vypnutý."
        ],
        "1.8": [
            "Podpora zvukového súboru",
            "rel_108_audio.jpg",
            "Prispôsobenie tlačidla prehrávania (poloha, veľkosť, okraj)",
            "rel_108_fab.jpg",
            "Prispôsobenie automatického pretočenia (2~4 sekundy pred)",
            "Oprava sťahovania TED v Android 11",
            "Automatický režim na šírku v režime na celú obrazovku (Voliteľné)"
        ],
        "1.7": [
            "Podpora tmavého režimu",
            "rel_107_darktheme.jpg",
            "Podpora viacero slovníkov - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "Oprava niektorých chýb - ovládač média v oznámeniach, slovník, prehliadač súborov, atď.",
        ],
        "1.6": [
            "Vylepšená funkcia slovníka (Automatické vyhľadávanie)",
            "rel_106_dicview.png",
            "Prispôsobiteľná farba a veľkosť titulkov",
            "Prispôsobiteľná priehľadnosť pozadia",
            "rel_106_css.jpg",
        ]
    }
  },
  "so": {
    "title": "Cuntada Cusub",
    "version": "Version",
    "rel": {
        "1.8.4": [
            "Hal dotin ugu wanaagsan oo loo fududeeyo, halka loo baahan yahay inaad ka daawato. (Fadlan iftiinka fududeeya.)",
        "rel_108_settings.jpg",
            "Waxaad ka bedeshaa maamulka daabacaada/buuqa wadaagga screen-ka maamulka.",
            "Nidaamka xiddiga qaybta si lama filaan ah."
        ],
        "1.8": [
            "Taageero faylka codka",
            "rel_108_audio.jpg",
            "Ku cusubid tundada shaqada (goobta, doolarka, margiinka)",
            "rel_108_fab.jpg",
            "Ku cusubid doonidii ugu qaalisan ee guriga (2~4 daqiiqo ka hor)",
            "Dabbaq soo saaray TED ee Android 11",
            "Nidaamka xiddiga qaybta si lama filaan ah ee wadnaha (La doonayo)"
        ],
        "1.7": [
            "Taageerada Themeka Madow",
            "rel_107_darktheme.jpg",
            "Taageerada kamamka luqadaha badan - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "Dib u eegisyo qaar ka mid ah khaladaha - guddiga wararka xidhiidhka, luqadda, baahiyaha faylasha, iwm.",
        ],
        "1.6": [
            "Faa'iidooyin tayada ah ee qaababka (Raadinaanshaha Aotomatigga)",
            "rel_106_dicview.png",
            "Midabka iyo cudurka titilada ee laga cusboonaan karo",
            "Daabacaadda nooca u cusboonaan kara ee hayska",
            "rel_106_css.jpg",
        ]
    }
  },
  "th": {
    "title": "คุณลักษณะใหม่",
    "version": "เวอร์ชัน",
    "rel": {
        "1.8.4": [
            "การแตะครั้งเดียวเพื่อเล่น/หยุดในโหมดแนวนอน (โปรดเปิดใช้งานในการตั้งค่า)",
        "rel_108_settings.jpg",
            "คุณสามารถปิดการควบคุมระดับเสียง/ความสว่างบนหน้าจอในการตั้งค่า",
            "โหมดแนวนอนอัตโนมัติถูกปิดใช้งานโดยค่าเริ่มต้น"
        ],
        "1.8": [
            "รองรับไฟล์เสียง",
            "rel_108_audio.jpg",
            "การปรับแต่งปุ่มเล่น (ตำแหน่ง, ขนาด, ระยะขอบ)",
            "rel_108_fab.jpg",
            "การปรับแต่งการหมุนถอยหลังโดยอัตโนมัติ (2~4 วินาทีก่อน)",
            "แก้ไขการดาวน์โหลด TED ใน Android 11",
            "โหมดแนวนอนอัตโนมัติในโหมดเต็มหน้าจอ (ตัวเลือก)"
        ],
        "1.7": [
            "รองรับธีมมืด",
            "rel_107_darktheme.jpg",
            "รองรับพจนานุกรมเพิ่มเติม - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "แก้ไขข้อผิดพลาดบางอย่าง - ตัวควบคุมสื่อการแจ้งเตือน, พจนานุกรม, เบราว์เซอร์ไฟล์, ฯลฯ"
        ],
        "1.6": [
            "ฟีเจอร์พจนานุกรมที่ปรับปรุง (การค้นหาอัตโนมัติ)",
            "rel_106_dicview.png",
            "สีและขนาดของคำบรรยายที่ปรับแต่งได้",
            "ความทึบของพื้นหลังที่ปรับแต่งได้",
            "rel_106_css.jpg"
        ]
    }
  },
  "tr": {
    "title": "Yenilikler",
    "version": "Sürüm",
    "rel": {
        "1.8.4": [
            "Manzara modunda tek dokunuşla oynat/duraklat (Lütfen ayarlarda etkinleştirin.)",
        "rel_108_settings.jpg",
            "Ayarlar bölümünde ekran üzerindeki ses/yükseklik kontrolünü devre dışı bırakabilirsiniz.",
            "Otomatik Manzara modu varsayılan olarak kapalıdır."
        ],
        "1.8": [
            "Ses dosyası desteği",
            "rel_108_audio.jpg",
            "Oynatma düğmesinin özelleştirilmesi (konum, boyut, kenar boşluğu)",
            "rel_108_fab.jpg",
            "Otomatik geri sarma özelleştirmesi (2~4 saniye önce)",
            "Android 11'de TED indirme sorununu düzeltin",
            "Tam ekran modunda Otomatik Manzara modu (İsteğe Bağlı)"
        ],
        "1.7": [
            "Karanlık tema desteği",
            "rel_107_darktheme.jpg",
            "Daha fazla sözlük desteği - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "Bazı hataları düzeltin - bildirim medya denetleyicisi, sözlük, dosya tarayıcısı vb."
        ],
        "1.6": [
            "Geliştirilmiş sözlük özelliği (Otomatik Arama)",
            "rel_106_dicview.png",
            "Özelleştirilebilir altyazı rengi ve boyutu",
            "Özelleştirilebilir arka plan opaklığı",
            "rel_106_css.jpg"
        ]
    }
  },
  "uk": {
    "title": "Нові Функції",
    "version": "Версія",
    "rel": {
        "1.8.4": [
            "Одне натискання для відтворення / паузи в режимі альбому (Будь ласка, увімкніть це в налаштуваннях.)",
        "rel_108_settings.jpg",
            "Ви можете вимкнути керування гучністю / яскравістю на екрані в налаштуваннях.",
            "Автоматичний режим альбому вимкнено за замовчуванням."
        ],
        "1.8": [
            "Підтримка аудіофайлів",
            "rel_108_audio.jpg",
            "Налаштування кнопки відтворення (положення, розмір, відступ)",
            "rel_108_fab.jpg",
            "Налаштування автоматичного перемотування (2~4 секунди перед)",
            "Виправлення завантаження TED в Android 11",
            "Автоматичний режим альбому в повноекранному режимі (Необов'язково)"
        ],
        "1.7": [
            "Підтримка темної теми",
            "rel_107_darktheme.jpg",
            "Підтримка більшої кількості словників - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "Виправлення деяких помилок - контролер медіа-повідомлень, словник, файловий браузер тощо.",
        ],
        "1.6": [
            "Покращена функція словника (Автоматичний пошук)",
            "rel_106_dicview.png",
            "Налаштовуваний колір та розмір субтитрів",
            "Налаштовувана прозорість фону",
            "rel_106_css.jpg",
        ]
    }
  },
  "uz": {
    "title": "Yangi Xususiyatlar",
    "version": "Versiya",
    "rel": {
        "1.8.4": [
            "Albom rejimida oynash / to‘xtatish uchun bir qo‘yish (Iltimos, sozlamalarda buni yoqing.)",
        "rel_108_settings.jpg",
            "Siz ekran volyum/yo‘qroqlikni boshqarishni sozlamalarda o‘chirishingiz mumkin.",
            "Avtomatik albom rejimi sukutda."
        ],
        "1.8": [
            "Audio fayl qo‘llab-quvvatlash",
            "rel_108_audio.jpg",
            "O‘ynash tugmasini moslashtirish (joylashuv, o‘lcham, bo‘shliq)",
            "rel_108_fab.jpg",
            "Avtomatik qaytarishni moslashtirish (oldingi 2~4 soniyada)",
            "Android 11 da TED yuklashni tuzatish",
            "To‘liq ekran rejimida avtomatik albom rejimi (Ixtiyoriy)"
        ],
        "1.7": [
            "Tungi mavzu qo‘llab-quvvatlash",
            "rel_107_darktheme.jpg",
            "Ko‘proq lug‘atlar qo‘llab-quvvatlash - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "Ba'zi xatolarni tuzatish - xabar mediya nazorat qurilmasi, lug'at, fayl brauzer va boshqalar.",
        ],
        "1.6": [
            "Lug'at funksiyasini kengaytirish (Avtomatik qidiruv)",
            "rel_106_dicview.png",
            "Subtitrlar rangi va o'lchami moslashuv",
            "Fon shaffofligi moslashuv",
            "rel_106_css.jpg",
        ]
    }
  },
  "vi": {
    "title": "Tính Năng Mới",
    "version": "Phiên Bản",
    "rel": {
        "1.8.4": [
            "Một lần chạm để phát / tạm dừng trong chế độ Ngang (Vui lòng bật nó trong cài đặt.)",
        "rel_108_settings.jpg",
            "Bạn có thể tắt điều khiển âm lượng / độ sáng trên màn hình trong cài đặt.",
            "Chế độ Ngang Tự động đã bị tắt mặc định."
        ],
        "1.8": [
            "Hỗ trợ file âm thanh",
            "rel_108_audio.jpg",
            "Tùy chỉnh nút phát (vị trí, kích thước, lề)",
            "rel_108_fab.jpg",
            "Tùy chỉnh tua tự động (2~4 giây trước)",
            "Sửa lỗi tải xuống TED trong Android 11",
            "Chế độ Ngang Tự động trong chế độ toàn màn hình (Tùy chọn)"
        ],
        "1.7": [
            "Hỗ trợ Chủ đề Tối",
            "rel_107_darktheme.jpg",
            "Hỗ trợ nhiều từ điển hơn - Google, WordReference, Wiktionary, Yandex, Cambridge, Oxford, Naver",
            "rel_107_dictsel.jpg",
            "Sửa một số lỗi - bộ điều khiển phương tiện thông báo, từ điển, trình duyệt tệp, v.v.",
        ],
        "1.6": [
            "Cải thiện tính năng từ điển (Tìm kiếm Tự động)",
            "rel_106_dicview.png",
            "Tùy chỉnh màu sắc và kích thước phụ đề",
            "Tùy chỉnh độ mờ nền",
            "rel_106_css.jpg",
        ]
    }
  },
  "zh": {
    "title": "新功能",
    "version": "版本",
    "rel": {
        "1.8.4": [
            "橫向模式一鍵播放/暫停（請在設置中啟用。）",
        "rel_108_settings.jpg",
            "您可以在設置中關閉屏幕上的音量/亮度控制。",
            "全屏模式下自動橫向模式默認關閉。"
        ],
        "1.8": [
            "支持音頻文件",
            "rel_108_audio.jpg",
            "播放按鈕自定義（位置、大小、邊距）",
            "rel_108_fab.jpg",
            "自動倒帶自定義（之前的2~4秒）",
            "修復Android 11中的TED下載",
            "全屏模式下的自動橫向模式（可選）"
        ],
        "1.7": [
            "支持深色主題",
            "rel_107_darktheme.jpg",
            "支持更多詞典 - Google、WordReference、Wiktionary、Yandex、Cambridge、Oxford、Naver",
            "rel_107_dictsel.jpg",
            "修復一些錯誤 - 通知媒體控制器、詞典、文件瀏覽器等。",
        ],
        "1.6": [
            "改進的詞典功能（自動搜索）",
            "rel_106_dicview.png",
            "可定制的字幕顏色和大小",
            "可定制的背景不透明度",
            "rel_106_css.jpg",
        ]
    }
  }
}

window.onload = function(){
  var url = location.href;
  // 언어 
  var lang = url.substring(url.lastIndexOf('=')+1);
  console.log(lang);
  var t = s[lang];
  if(!t && lang.length > 2){
    lang = lang.substring(0, 2);
    console.log(lang);
    t = s[lang];
  }
  if(!t) t = s['en'];
  // 화면 구성
  var html = '<div class="title"><H1 class="txt" id="title">'+t.title+'</H1></div>';
  Object.keys(t.rel).forEach((ver) => {
    html += '<div class="title"><H3><span class="txt version">'+t.version+'</span> : '+ver+'</H3></div>';
    html += '<div style="display:flex;flex-wrap:wrap;justify-content: center;">';
    t.rel[ver].forEach((l)=>{
      if(l.endsWith('jpg')||l.endsWith('png')){
        html+='<div class="c2"><img src="'+l+'"/></div>';
      } else {
        html+='<div class="c3"><ul class="list"><li><span class="txt bold">'+l+'</span></li></ul></div>';
      }
    })
    html += '</div>'
  })
  document.body.innerHTML = html;
  
  // RTL 처리
  var rtl = ["ar","fa"];
  if(rtl.includes(lang)){
    var l = document.getElementsByTagName("ul");
    for(var i = 0; i < l.length; i++)
      l[i]["dir"]="rtl";
  }
}
