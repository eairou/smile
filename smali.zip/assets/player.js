var videoFile, subtitleFiles = [], scripts = {}, subtitlesChanged = false, position;
var reader = new FileReader();

function onFileSelected(event){
  //console.log("** onFileSelected()")
  var files = event.target.files;
  var file, l = files.length;
  for(var i = 0; i < l; i++){
    file = files[i];
    //console.log("**** "+file.name);
    if(/.*\.(smi|srt)/.test(file.name)){
      //TODO filename으로 체크 로직 넣으면 무한 루프 빠짐
      subtitleFiles.push(file);
    } else if(/.*\.(mp4|mkv|avi|webm|mp3|m4a)/.test(file.name)){
      if(checkPlayable(file)){
        videoFile = file;
        // var raw = lingoHost.getSubtitleInfo(file.name);
        // console.log(raw);
        // subtitleInfo = JSON.parse(raw);  // 해당 동영상의 자막 설정 정보
        subtitleInfo = {};
        document.getElementById('title').innerText = videoFile.name;
        lingoApp.handler.vid="local";
        lingoApp.handler.title = videoFile.name;
        lingoApp.setAudioMode(/.*\.(mp3|m4a)/.test(file.name));
      } else {
        //console.log("ERR! Can't play")
      }
    }
  }
  if(videoFile) loadSubtitles();
  event.target.value = "";
}

function postFileSelected(){
  updateStatus();
  if(shouldAutoStart){
    startPlay();
    shouldAutoStart = false;
  }
}

function loadSubtitles(){
  var info;
  //DB에서 값 가져오기
  subtitlesChanged = false;
  for(i in subtitleFiles){
    file = subtitleFiles[i];
    if(!file.loaded){  // 중복 조회 방지코드
      info = subtitleInfo[file.name];
      if(info){
        file.langs = info.langs;
        file.enc = info.enc;
      }
    }
  }
  loadSubRecursive(0);
};

function loadSubRecursive(i){
  if(i >= subtitleFiles.length){
    postFileSelected();
    return;
  }
  var file = subtitleFiles[i];
  if(file.loaded){ // 중복 처리 방지
    loadSubRecursive(i+1);
    return;
  }
  if(!file.enc){
    subtitlesChanged = true;
    var data = lingoHost.detectCharset(file.name).split(',');
    //console.log("** lingoHost.detectCharset("+file.name+") "+data);
    file.enc = data[0];
    if(data.length > 1 && data[1] != "null") file.lang = data[1];
  }
  //console.log('** loadSubRecursive('+i+"), enc="+file.enc+", lang="+file.lang+', file='+file.name);
  if(file.enc === "auto"){
    // 파일 인코딩 검출
    reader.onload = function(ev){
      var r = jschardet.detect(reader.result);
      //console.log('**** detect encoding = '+r.encoding+", "+r.confidence);
      file.enc = r.encoding;
      setTimeout(loadSubRecursive.bind(this), 50, i);
    }
    reader.readAsBinaryString(file);
  } else {
    readSubFile(file, loadSubRecursive, i + 1);
  }
}

function readSubFile(file, callback, param){
  file.langs = [];
  // SRT 언어 검출
  if(!file.lang && file.name.endsWith('srt')){
    file.lang = guessLangFromFileName(file.name);
  }
  // 캡션 읽기 및 SMI 언어 검출
  reader.onload = function(ev) {
    var text = this.result;
    var ret;
    if(file.name.endsWith('smi')){
      ret = samiParser.parse(text, configs={});
    } else {
      ret = srtParser.parse(text, file.lang);
    }
    //console.log(ret);
    if(!ret.errors || ret.errors.length==0){
      var result = ret.result;
      //console.log("** readSubFile() loaded: " + Object.keys(result).toString());
      //console.log(result[Object.keys(result)[0]].captions[2]);
      var lang;
      for(var k in result){
        lang = result[k].lang;
        file.langs.push(lang);
      }
      scripts = Object.assign(scripts, result);
      file.loaded = true;
      var info = subtitleInfo[file.name];
      if(!info){
        info = subtitleInfo[file.name] = {};
      }
      info.langs = file.langs;
      info.enc = file.enc;
      subtitlesChanged = true;
    }
    if(callback) callback(param);
  }
  reader.readAsText(file, file.enc);
};

function checkPlayable(file){
  var type = file.name.endsWith('mkv')?"video/mp4":file.type;
  var canPlay = videoNode.canPlayType(type)
  //console.log(">> checkPlayable() type="+type+", playable:"+canPlay);
  return (canPlay != '');
}

function updateStatus(){
  //console.log(">> updateStatus()");
  var file, s, shouldAddLang;
  statusDiv.innerHTML = "";
  var t;
  if(videoFile){
    var div = document.createElement('div');
    t = document.getElementById('video_template');
    div.innerHTML = t.innerHTML;
    div.classList = t.classList;
    div.getElementsByClassName('info_filename')[0].innerHTML = videoFile.name;
    statusDiv.append(div);
  }
  // 노출 자막을 앞에 나오도록 순서 조정
  var i, j, l, tlangFile = [], mlangFile = [];
  var tlang = lingoApp.config.targetLang;
  var mlang = lingoApp.config.motherLang;
  var newList = subtitleFiles.slice();
  for(var i in subtitleFiles){
    file = subtitleFiles[i];
    for(j in file.langs){
      l = file.langs[j];
      if(l.startsWith(tlang)){
        tlangFile.push(file);
        newList.splice(newList.indexOf(file), 1);
      } else if(l.startsWith(mlang)){
        mlangFile.push(file);
        newList.splice(newList.indexOf(file), 1);
      }
    }
  }
  for(i in mlangFile){
    newList.unshift(mlangFile[i]);
  }
  for(i in tlangFile){
    newList.unshift(tlangFile[i]);
  }
  subtitleFiles = newList;
  var elem;
  t = document.getElementById('subtitle_template');
  for(var i in subtitleFiles){
    file = subtitleFiles[i];
    var div = document.createElement('div');
    div.innerHTML = t.innerHTML;
    div.classList = t.classList;
    elem = div.getElementsByClassName('info_filename')[0];
    elem.innerHTML = file.name;
    elem.classList.add('info_subtitle');
    var s, v;
    if(file.name.endsWith('srt')){
      s = '<select onchange="changeLang('+i+', this.value)"">';
      for(var l in langcode){
        s += '<option value="'+l+'"'+(l==file.langs[0]?' selected>':'>')+langcode[l]+'</option>';
      }
      s+='</select>';
    } else {
      var l, ll = [];
      for(var j in file.langs){
        ll.push(scripts[file.langs[j]].name);
      }
      s = ll.toString();
    }
    div.getElementsByClassName('info_lang')[0].innerHTML = s;
    s = '<select onchange="changeEncoding('+i+', this.value)"><option  value="'+file.enc+'" selected>'+file.enc+'</option>';
    var cs;
    for(var c in charsets){
      cs = charsets[c];
      if(file.enc != cs)
        s+='<option value="'+cs+'">'+cs+'</option>';
    }
    s+='</select>'
    div.getElementsByClassName('info_encoding')[0].innerHTML = s;
    div.getElementsByClassName('delete')[0].onclick = removeSubtitle;
    div.file = file;
    statusDiv.append(div);
  }
  if(videoFile){
    if(!videoNode.src) document.getElementById('play').style.display = 'block';
//    document.getElementById('videoButton').style.display = 'none';
  } else {
    document.getElementById('play').style.display = 'none';
//    document.getElementById('videoButton').style.display = 'block';
  }
};

function removeSubtitle(event){
  var f = event.srcElement.parentElement.parentElement.parentElement.file;
  subtitleFiles.splice(subtitleFiles.indexOf(f), 1);
  scripts = {};
  for(var i in subtitleFiles){
    subtitleFiles[i].loaded = false;
  }
  loadSubRecursive(0);
  subtitlesChanged = true;
}

function changeEncoding(i, enc){
  var file = subtitleFiles[i];
  file.enc = enc;
  readSubFile(file, function(){
    if(videoNode.src && vinfo.mainScript){  // 재생 중인 경우 동적으로 변경
      lingoApp.setDisplayScripts();
      lingoApp.syncCaptions();
      lingoApp.loadUserCaptions();
      lingoApp.updateScriptDiv();
    }
  });
}

function changeLang(i, lang){
  var file = subtitleFiles[i];
  var l = file.lang;
  file.lang = lang;
  readSubFile(file, function(){
    if(videoNode.src && vinfo.mainScript){  // 재생 중인 경우 동적으로 변경
      lingoApp.setDisplayScripts();
      lingoApp.updateScriptDiv();
    }
  });
}

function startPlay() {
  //console.log("** startPlay()");
  if(!videoNode.src){
    videoNode.src = URL.createObjectURL(videoFile);
    // if(window.lingoHost){
    //   window.lingoHost.onFullScreenChanged(false);
    // }
    document.getElementById('loading').style.display='none';
    if(getParameterByName('fs')!=null){
      lingoApp.setScreenMode('fullscreen');
      if(window.lingoHost){
        window.lingoHost.setLandscape(true);
        setTimeout(function(){window.lingoHost.setLandscape(false);}, 5000);
      }
    }
    document.getElementById('play').style.display = 'none';
  }
  var screenmode
  videoNode.play();
  if(!subtitlesChanged){
    if(Object.keys(scripts).length==0) {
      scripts.err = "no_captions";
      screenmode = 'fullscreen';
    } else {
      delete scripts.err;
    }
    lingoApp.start(null, screenmode); // subtitlesChanged=true인 경우 onplay()에서 호출함
    playerLayout.onclick = lingoApp.controller.setVisible.bind(lingoApp.controller);
  }
}

function onControllerShown(shown){
  document.getElementById('head_layer').style.display=shown?null:'none';
}

function stop(){
  videoNode.pause();
  videoNode.removeAttribute('src');
  videoNode.load()
  setMode('intro');
  lingoApp.finish();
  videoFile = undefined;
  subtitleFiles = [];
  scripts = {};
  updateStatus();
}

function settings(){
  videoNode.pause();
  window.location.href = "#config";
  btnClose.style.display = null;
}

function onplay(){
  if(position){
    videoNode.currentTime = position;
    position = undefined;
  }
  if(subtitlesChanged) {
    lingoHost.setSubtitleInfo(videoFile.name, JSON.stringify(subtitleInfo));
    subtitlesChanged = false;
    var screenmode
    if(Object.keys(scripts).length==0) {
      scripts.err = "no_captions";
      screenmode = 'fullscreen';
    } else {
      delete scripts.err;
    }
    lingoApp.start(null, screenmode);
    playerLayout.onclick = lingoApp.controller.setVisible.bind(lingoApp.controller);
  }
  if(location.href.endsWith('config')) history.back();
  else setMode('video');
}


function setMode(mode){
  //console.log('** setMode() '+mode);
  if(mode==='video'){
    playerLayout.style.display='flex';
    document.getElementById('button_layout').style.display='none';
    btnClose.style.display = 'none';
  } else {
    playerLayout.style.display='none';
    document.getElementById('button_layout').style.display='block';
    document.getElementById('loading').style.display='none';
  }
}

function guessLangFromFileName(fn){
  var match = /.*?[-\.](.{2,3}?)([_-](.{2,3}?))?(.srt)$/g.exec(fn);
  if(match){
    var lang = match[1].toLowerCase();
    //console.log('l='+lang+', r='+match[3]);
    if(lang.length > 2 ){
      // 3자리 언어코드 -> 2자리 언어코드
      var l = lang3Digit[lang];
      if(l) lang = l;
    }
    if(match[3]){
      var region = match[3].toUpperCase();
      return lang+'_'+region;
    } else return lang;
  }
  return 'en';
};

function getParameterByName(name, url) {
  if (!url) url = window.location.href;
  name = name.replace(/[\[\]]/g, '\\$&');
  var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
      results = regex.exec(url);
  if (!results) return null;
  if (!results[2]) return '';
  return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

function postInit(){
  //console.log(">> postInit()");
  // loadLingo()가 먼저 호출되는 경우와 window.onload()가 먼저 호출되는 경우 모두 고려해야 함
  if(!statusDiv || !window.lingoApp) return;
  window.lingoHost.onControllerShown = onControllerShown;
  langcode = JSON.parse(lingoHost.getLanguages());
  var i = setInterval(function(){if(window.lingoHost){window.lingoHost.showToolbar(false);clearInterval(i)}}, 100);
  updateStatus();
  if(window.lingoHost && shouldAutoStart){
      window.lingoHost.onLoad();
  } else {
    setMode('intro');
  }
}

window.onhashchange = function(){
  var url = window.location.href;
  if(url.endsWith('config')){
    this.setMode('config');
  } else {
    this.setMode('video');
  }
}

var params;

window.onload = function(){
  //console.log("** onload() "+window.location.href);
  var i = window.location.href.indexOf('#');
  if(i > 0 ){
    window.location.href = window.location.href.substring(0, i);
  }
  shouldAutoStart = getParameterByName('play')!=null
  var p = this.getParameterByName('t');
  position = p?Number(p.replace('s','')):undefined;
  videoNode = document.querySelector('video');
  videoNode.addEventListener('play', onplay);
  videoNode.addEventListener('error', (event) => {
    //console.log(event.toString());
    window.lingoHost.onVideoError('dec_err'); // 동영상 분석이 안되는 경우
  })
  playerLayout = document.getElementById('player_layout');
  videoNode.getSubtitleType = function(){return "smi"};
  videoNode.getSubtitles = function(){return JSON.stringify(window.sami)};
  var inputFile = document.getElementById('inputFile');
  inputFile.addEventListener('change', onFileSelected, false);
  statusDiv = document.getElementById('status');
  btnClose = document.getElementById('btnClose');
  btnClose.onclick = function(){
    history.back();
  }
  if(this.getParameterByName('rtl')!=null) document.body.dir = 'rtl';
  loadLingo();
}