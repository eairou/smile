window.CSSParser = function(css, options){
    options = options || {};

    /**
     * Positional.
     */

    var lineno = 1;
    var column = 1;

    /**
     * Update lineno and column based on `str`.
     */

    function updatePosition(str) {
        var lines = str.match(/\n/g);
        if (lines) lineno += lines.length;
        var i = str.lastIndexOf('\n');
        column = ~i ? str.length - i : column + str.length;
    }

    /**
     * Mark position and patch `node.position`.
     */

    function position() {
        var start = { line: lineno, column: column };
        if (!options.position) return positionNoop;

        return function(node){
        node.position = {
            start: start,
            end: { line: lineno, column: column }
        };

        whitespace();
        return node;
        }
    }

    /**
     * Return `node`.
     */

    function positionNoop(node) {
        whitespace();
        return node;
    }

    /**
     * Error `msg`.
     */

    function error(msg) {
        var err = new Error(msg + ' near line ' + lineno + ':' + column);
        err.line = lineno;
        err.column = column;
        err.source = css;
        throw err;
    }

    /**
     * Parse stylesheet.
     */

    function stylesheet() {
        return {
        type: 'stylesheet',
        stylesheet: {
            rules: rules()
        }
        };
    }

    /**
     * Opening brace.
     */

    function open() {
        return match(/^{\s*/);
    }

    /**
     * Closing brace.
     */

    function close() {
        return match(/^}/);
    }

    /**
     * Parse ruleset.
     */

    function rules() {
        var node;
        var rules = [];
        whitespace();
        comments(rules);
        while (css.charAt(0) != '}' && (node = atrule() || rule())) {
        rules.push(node);
        comments(rules);
        }
        return rules;
    }

    /**
     * Match `re` and return captures.
     */

    function match(re) {
        var m = re.exec(css);
        if (!m) return;
        var str = m[0];
        updatePosition(str);
        css = css.slice(str.length);
        return m;
    }

    /**
     * Parse whitespace.
     */

    function whitespace() {
        match(/^\s*/);
    }

    /**
     * Parse comments;
     */

    function comments(rules) {
        var c;
        rules = rules || [];
        while (c = comment()) rules.push(c);
        return rules;
    }

    /**
     * Parse comment.
     */

    function comment() {
        var pos = position();
        if ('/' != css.charAt(0) || '*' != css.charAt(1)) return;

        var i = 2;
        while (null != css.charAt(i) && ('*' != css.charAt(i) || '/' != css.charAt(i + 1))) ++i;
        i += 2;

        var str = css.slice(2, i - 2);
        column += 2;
        updatePosition(str);
        css = css.slice(i);
        column += 2;

        return pos({
        type: 'comment',
        comment: str
        });
    }

    /**
     * Parse selector.
     */

    function selector() {
        var m = match(/^([^{]+)/);
        if (!m) return;
        return trim(m[0]).split(/\s*,\s*/);
    }

    /**
     * Parse declaration.
     */

    function declaration() {
        var pos = position();

        // prop
        var prop = match(/^(\*?[-\/\*\w]+)\s*/);
        if (!prop) return;
        prop = trim(prop[0]);

        // :
        if (!match(/^:\s*/)) return error("property missing ':'");

        // val
        var val = match(/^((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^\)]*?\)|[^};])+)/);
        if (!val) return error('property missing value');

        var ret = pos({
        type: 'declaration',
        property: prop,
        value: trim(val[0])
        });

        // ;
        match(/^[;\s]*/);

        return ret;
    }

    /**
     * Parse declarations.
     */

    function declarations() {
        var decls = [];

        if (!open()) return error("missing '{'");
        comments(decls);

        // declarations
        var decl;
        while (decl = declaration()) {
        decls.push(decl);
        comments(decls);
        }

        if (!close()) return error("missing '}'");
        return decls;
    }

    /**
     * Parse keyframe.
     */

    function keyframe() {
        var m;
        var vals = [];
        var pos = position();

        while (m = match(/^(from|to|\d+%|\.\d+%|\d+\.\d+%)\s*/)) {
        vals.push(m[1]);
        match(/^,\s*/);
        }

        if (!vals.length) return;

        return pos({
        type: 'keyframe',
        values: vals,
        declarations: declarations()
        });
    }

    /**
     * Parse keyframes.
     */

    function atkeyframes() {
        var pos = position();
        var m = match(/^@([-\w]+)?keyframes */);

        if (!m) return;
        var vendor = m[1];

        // identifier
        var m = match(/^([-\w]+)\s*/);
        if (!m) return error("@keyframes missing name");
        var name = m[1];

        if (!open()) return error("@keyframes missing '{'");

        var frame;
        var frames = comments();
        while (frame = keyframe()) {
        frames.push(frame);
        frames = frames.concat(comments());
        }

        if (!close()) return error("@keyframes missing '}'");

        return pos({
        type: 'keyframes',
        name: name,
        vendor: vendor,
        keyframes: frames
        });
    }

    /**
     * Parse supports.
     */

    function atsupports() {
        var pos = position();
        var m = match(/^@supports *([^{]+)/);

        if (!m) return;
        var supports = trim(m[1]);

        if (!open()) return error("@supports missing '{'");

        var style = comments().concat(rules());

        if (!close()) return error("@supports missing '}'");

        return pos({
        type: 'supports',
        supports: supports,
        rules: style
        });
    }

    /**
     * Parse media.
     */

    function atmedia() {
        var pos = position();
        var m = match(/^@media *([^{]+)/);

        if (!m) return;
        var media = trim(m[1]);

        if (!open()) return error("@media missing '{'");

        var style = comments().concat(rules());

        if (!close()) return error("@media missing '}'");

        return pos({
        type: 'media',
        media: media,
        rules: style
        });
    }

    /**
     * Parse paged media.
     */

    function atpage() {
        var pos = position();
        var m = match(/^@page */);
        if (!m) return;

        var sel = selector() || [];

        if (!open()) return error("@page missing '{'");
        var decls = comments();

        // declarations
        var decl;
        while (decl = declaration()) {
        decls.push(decl);
        decls = decls.concat(comments());
        }

        if (!close()) return error("@page missing '}'");

        return pos({
        type: 'page',
        selectors: sel,
        declarations: decls
        });
    }

    /**
     * Parse document.
     */

    function atdocument() {
        var pos = position();
        var m = match(/^@([-\w]+)?document *([^{]+)/);
        if (!m) return;

        var vendor = trim(m[1]);
        var doc = trim(m[2]);

        if (!open()) return error("@document missing '{'");

        var style = comments().concat(rules());

        if (!close()) return error("@document missing '}'");

        return pos({
        type: 'document',
        document: doc,
        vendor: vendor,
        rules: style
        });
    }

    /**
     * Parse import
     */

    function atimport() {
        return _atrule('import');
    }

    /**
     * Parse charset
     */

    function atcharset() {
        return _atrule('charset');
    }

    /**
     * Parse namespace
     */

    function atnamespace() {
        return _atrule('namespace')
    }

    /**
     * Parse non-block at-rules
     */

    function _atrule(name) {
        var pos = position();
        var m = match(new RegExp('^@' + name + ' *([^;\\n]+);'));
        if (!m) return;
        var ret = { type: name };
        ret[name] = trim(m[1]);
        return pos(ret);
    }

    /**
     * Parse at rule.
     */

    function atrule() {
        return atkeyframes()
        || atmedia()
        || atsupports()
        || atimport()
        || atcharset()
        || atnamespace()
        || atdocument()
        || atpage();
    }

    /**
     * Parse rule.
     */

    function rule() {
        var pos = position();
        var sel = selector();

        if (!sel) return;
        comments();

        return pos({
        type: 'rule',
        selectors: sel,
        declarations: declarations()
        });
    }

    return stylesheet();
    };

    /**
     * Trim `str`.
     */

    function trim(str) {
    return (str || '').replace(/^\s+|\s+$/g, '');
    }


(function() {
    var clone, cssParse, reBr, reBrokenTag, reCloseSync, reComment, reLineEnding, reOpenSync, reStartTime, reStyle, _mergeMultiLanguages, _sort;
  
    cssParse = window.CSSParser;  
  
    reOpenSync = /<sync/i;
  
    reCloseSync = /<sync|<\/body|<\/sami/i;
  
    reLineEnding = /\r\n?|\n/g;
  
    reBrokenTag = /<[a-z]*[^>]*<[a-z]*/g;
  
    reStartTime = /<sync[^>]+?start[^=]*=[^0-9]*([0-9]*)["^0-9"]*/i;
  
    reBr = /<br[^>]*>/ig;
  
    reStyle = /<style[^>]*>([\s\S]*?)<\/style[^>]*>/i;
  
    reComment = /(<!--|-->)/g;
  
    clone = function(obj) {
      var flags, key, newInstance;
      if ((obj == null) || typeof obj !== 'object') {
        return obj;
      }
      if (obj instanceof Date) {
        return new Date(obj.getTime());
      }
      if (obj instanceof RegExp) {
        flags = '';
        if (obj.global != null) {
          flags += 'g';
        }
        if (obj.ignoreCase != null) {
          flags += 'i';
        }
        if (obj.multiline != null) {
          flags += 'm';
        }
        if (obj.sticky != null) {
          flags += 'y';
        }
        return new RegExp(obj.source, flags);
      }
      newInstance = new obj.constructor();
      for (key in obj) {
        newInstance[key] = clone(obj[key]);
      }
      return newInstance;
    };
  
    function strip_tags(input, allowed) {
    // http://kevin.vanzonneveld.net
    // +   original by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +   improved by: Luke Godfrey
    // +      input by: Pul
    // +   bugfixed by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +   bugfixed by: Onno Marsman
    // +      input by: Alex
    // +   bugfixed by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +      input by: Marc Palau
    // +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +      input by: Brett Zamir (http://brett-zamir.me)
    // +   bugfixed by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +   bugfixed by: Eric Nagel
    // +      input by: Bobby Drake
    // +   bugfixed by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +   bugfixed by: Tomasz Wesolowski
    // +      input by: Evertjan Garretsen
    // +    revised by: Rafał Kukawski (http://blog.kukawski.pl/)
    // *     example 1: strip_tags('<p>Kevin</p> <br /><b>van</b> <i>Zonneveld</i>', '<i><b>');
    // *     returns 1: 'Kevin <b>van</b> <i>Zonneveld</i>'
    // *     example 2: strip_tags('<p>Kevin <img src="someimage.png" onmouseover="someFunction()">van <i>Zonneveld</i></p>', '<p>');
    // *     returns 2: '<p>Kevin van Zonneveld</p>'
    // *     example 3: strip_tags("<a href='http://kevin.vanzonneveld.net'>Kevin van Zonneveld</a>", "<a>");
    // *     returns 3: '<a href='http://kevin.vanzonneveld.net'>Kevin van Zonneveld</a>'
    // *     example 4: strip_tags('1 < 5 5 > 1');
    // *     returns 4: '1 < 5 5 > 1'
    // *     example 5: strip_tags('1 <br/> 1');
    // *     returns 5: '1  1'
    // *     example 6: strip_tags('1 <br/> 1', '<br>');
    // *     returns 6: '1  1'
    // *     example 7: strip_tags('1 <br/> 1', '<br><br/>');
    // *     returns 7: '1 <br/> 1'
    allowed = (((allowed || "") + "").toLowerCase().match(/<[a-z][a-z0-9]*>/g) || []).join(''); // making sure the allowed arg is a string containing only tags in lowercase (<a><b><c>)
    var tags = /<\/?([a-z][a-z0-9]*)\b[^>]*>/gi,
      commentsAndPhpTags = /<!--[\s\S]*?-->|<\?(?:php)?[\s\S]*?\?>/gi;
    return input.replace(/\n/gi, ' ').replace(commentsAndPhpTags, '').replace(tags, function($0, $1) {
      return allowed.indexOf('<' + $1.toLowerCase() + '>') > -1 ? $0 : '';
    });
  };
  
    _sort = function(langItem) {
      return langItem.sort(function(a, b) {
        var res;
        if ((res = a.startTime - b.startTime) === 0) {
          return a.endTime - b.endTime;
        } else {
          return res;
        }
      });
    };
  
    _mergeMultiLanguages = function(arr) {
      var content, dict, i, idx, key, lang, ret, val, _i, _len, _ref;
      dict = {};
      i = arr.length;
      ret = [];
      for (i = _i = 0, _len = arr.length; _i < _len; i = ++_i) {
        val = arr[i];
        key = val.startTime + ',' + val.endTime;
        if ((idx = dict[key]) !== void 0) {
          _ref = val.languages;
          for (lang in _ref) {
            content = _ref[lang];
            ret[idx].languages[lang] = content;
          }
        } else {
          ret.push(val);
          dict[key] = ret.length - 1;
        }
      }
      return ret;
    };
  
    window.parseSami = function(sami, options) {
      var definedLangs, duration, errors, getDefinedLangs, getLanguage, key, makeEndTime, parse, result, value, _ref;
      parse = function() {
        var element, error, innerText, isBroken, item, lang, langItem, lineNum, nextStartTagIdx, ret, startTagIdx, startTime, str, tempRet, _ref, _ref1, _ref2;
        var scripts = {}, c, caption, script;
        error = function(error) {
          var e;
          e = new Error(error);
          e.line = lineNum;
          e.context = element;
          return errors.push(e);
        };
        lineNum = 1;
        ret = [];
        tempRet = {};
        str = sami;
        while (true) {
          startTagIdx = str.search(reOpenSync);
          if (nextStartTagIdx <= 0 || startTagIdx < 0) {
            break;
          }
          nextStartTagIdx = str.slice(startTagIdx + 1).search(reCloseSync) + 1;
          if (nextStartTagIdx > 0) {
            element = str.slice(startTagIdx, startTagIdx + nextStartTagIdx);
          } else {
            element = str.slice(startTagIdx);
          }
          lineNum += ((_ref = str.slice(0, startTagIdx).match(reLineEnding)) != null ? _ref.length : void 0) || 0;
          if (isBroken = reBrokenTag.test(element)) {
            error('ERROR_BROKEN_TAGS');
          }
          str = str.slice(startTagIdx + nextStartTagIdx);
          startTime = (+((_ref1 = element.match(reStartTime)) != null ? _ref1[1] : void 0))/1000;
          if (startTime === null || startTime < 0) {
            error('ERROR_INVALID_TIME');
          }
          lang = getLanguage(element).replace('-', '_');
          if (!lang) {
            error('ERROR_INVALID_LANGUAGE');
          }
          // 한국어 시장 표준 보정 : 'kr_KR' -> 'ko_KR'
          if(lang=='kr_KR') lang = 'ko_KR';
          script = scripts[lang];
          if(!script){
            script = scripts[lang] = new Script(lang);
            script.status = 1;
          }
          lineNum += ((_ref2 = element.match(reLineEnding)) != null ? _ref2.length : void 0) || 0;
          element = element.replace(reLineEnding, ' ');
          element = element.replace(reBr, "\n");
          innerText = strip_tags(element).trim();
          // 기존 자막 정리
          if(caption){
            if(caption.text==="" && (startTime - caption.start) < 1 ){
              script.captions.splice(script.captions.length-1, 1);
            } else {
              caption.end = Math.round((startTime - 0.1)*1000)/1000;
            }
          }
          // 새자막 생성
          caption = {start:startTime, text:innerText=='&nbsp;'?"":innerText}
          script.captions.push(caption);
        }
        return scripts;
      };
      getLanguage = function(element) {
        var className, lang;
        for (className in definedLangs) {
          lang = definedLangs[className];
          if (lang.reClassName.test(element)) {
            return lang.lang;
          }
        }
      };
      getLanguageName = function(lang, element){
        var l = lang.split('_'), name;
        if(l[1]){
          name = langcode[lang];
          if(name) return name;
        }
        name = langcode[l[0]];
        if(name) return name;
        else if(element){
          var className, lang;
          for (className in definedLangs) {
            lang = definedLangs[className];
            if (lang.reClassName.test(element)) {
              return lang.name;
            }
          }
        }
      };
      getDefinedLangs = function() {
        var className, declaration, e, error, lang, matched, parsed, rule, selector, _i, _len, _ref, _ref1, _results;
        try {
          matched = ((_ref = sami.match(reStyle)) != null ? _ref[1] : void 0) || '';
          matched = matched.replace(reComment, '');
          parsed = cssParse(matched);
          _ref1 = parsed.stylesheet.rules;
          for(var i in parsed.stylesheet.rules){
            rule = parsed.stylesheet.rules[i];
            selector = rule.selectors[0];
            var l = {};
            if ((selector != null ? selector[0] : void 0) === '.') {
              className = selector.slice(1);
              for(var j in rule.declarations){
                declaration = rule.declarations[j];
                if(declaration.property === 'lang'){
                  l.lang = declaration.value;
                } else if(declaration.property === 'Name'){
                  l.name = declaration.value;
                }
              }
              if(l.lang){
                l.reClassName = new RegExp("class[^=]*?=[\"'\S]*(" + className + ")['\"\S]?", 'i')
                definedLangs[className] = l;
              }
            }
          }
          return definedLangs;
        } catch (_error) {
          e = _error;
          errors.push(error = new Error('ERROR_INVALID_LANGUAGE_DEFINITION'));
        }
      };
      makeEndTime = function(langItem) {
        var i, item, _ref;
        i = langItem.length;
        while (i--) {
          item = langItem[i];
          if ((_ref = langItem[i - 1]) != null) {
            _ref.endTime = item.startTime;
          }
          if (!item.contents || item.contents === '&nbsp;') {
            langItem.splice(i, 1);
          } else {
            delete langItem[i].contents;
            if (!item.endTime) {
              item.endTime = item.startTime + duration;
            }
          }
        }
        return langItem;
      };
      errors = [];
      definedLangs = {
        KRCC: {
          lang: 'ko',
          name: 'Korean',
          reClassName: new RegExp("class[^=]*?=[\"'\S]*(KRCC)['\"\S]?", 'i')
        },
        KR: {
          lang: 'ko',
          name: 'Korean',
          reClassName: new RegExp("class[^=]*?=[\"'\S]*(KR)['\"\S]?", 'i')
        },
        ENCC: {
          lang: 'en',
          name: 'English',
          reClassName: new RegExp("class[^=]*?=[\"'\S]*(ENCC)['\"\S]?", 'i')
        },
        EGCC: {
          lang: 'en',
          name: 'English',
          reClassName: new RegExp("class[^=]*?=[\"'\S]*(EGCC)['\"\S]?", 'i')
        },
        EN: {
          lang: 'en',
          name: 'English',
          reClassName: new RegExp("class[^=]*?=[\"'\S]*(EN)['\"\S]?", 'i')
        },
        JPCC: {
          lang: 'ja',
          name: 'Japanese',
          reClassName: new RegExp("class[^=]*?=[\"'\S]*(JPCC)['\"\S]?", 'i')
        }
      };
      if (options != null ? options.definedLangs : void 0) {
        _ref = options.definedLangs;
        for (key in _ref) {
          value = _ref[key];
          definedLangs[key] = value;
        }
      }
      duration = (options != null ? options.duration : void 0) || 10000;
      sami = sami.trim();
      getDefinedLangs();
      result = parse();
      return {
        result: result,
        errors: errors
      };
    };
  
  }).call(this);
  
window.samiParser = {
    parse: function(str, options) {
        if (options == null) {
        options = {};
        }
        return window.parseSami(str, options);
    },
};
