window.srtParser = function(){
    this.parse = function(txt, lang){
        if(!lang) lang = 'en';
        var name = langcode[lang];
        if(!name){
            var d = lang.split('_');
            lang = (d.length > 1)?d[0]:'en';
        }
        var script = new Script(lang);
        var delim = txt.indexOf('\r\n\r\n')>0?'\r\n':'\n';
        var list = txt.split(delim+delim), time, caption, start, end;
        for(var i in list){
            n = list[i].trimStart().split(delim);
            if(n.length < 3) continue;
            time = n[1].split(' --> ');
            start = calTime(time[0]);
            if(end != 0 && start - end > 1){
              script.captions.push({start:end+0.01, end:start-0.01, text:""});
            }
            end = calTime(time[1])
            caption = {
                start:start,
                end:end,
                text:n.slice(2).join(' ')
            };
            script.captions.push(caption);
        }
        if(script.captions.length > 0){
            script.status = 1;
            var result = {};
            result[script.lang] = script;
            return {result:result};
        } else {
            return {errors:['no captions']}
        }
    };
    return this;
}();

function calTime(str){
    try {
        var d1 = str.split(',');
        var d2 = d1[0].split(':');
        var d = Number('0.'+d1[1]) + Number(d2[2]) + Number(d2[1])*60 + Number(d2[0])*60*60;
        return d;
    } catch(err){
        console.log(err);
        return 0;
    }
}

