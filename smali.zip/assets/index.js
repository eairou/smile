var data;
var IMAGE_FOLDER;
var contents, groups;
var watching, bookmark, _history, catalog, historyDiv, sentences, titles, expressions = [];

console.log('hi!');

function loadData(){
    //console.log("loadData()")
    var progress = document.getElementById('loading');
    progress.style.display=null;
    var raw = window.home.getCatalog();
    var json = JSON.parse(raw);
    IMAGE_FOLDER = json.imageFolder;
    groups = json.groups;
    contents = json.contents;
    _history = json.history;
    _history.removable = true;
    // Catalog 생성
    catalog = {};
    var gid, id, content, now = Date.now();
    for(id in contents){
        content = contents[id];
        if(!content.id) content.id = id;
        gid = content.gid;
        if(!gid) continue;
        if(!catalog[gid]) catalog[gid] = [];
        catalog[gid].push(id);
    }
    // Catalog 정렬
    var list, newlist, watchedlist, id;
    for(var g in catalog){
        list = catalog[g];
        newlist = [];
        watchedlist = [];
        for(var i in list){
            id = list[i];
            content = contents[id];
            if(content.last==0) newlist.push(id);
            else watchedlist.push(id);
        }
        watchedlist.sort(function(a, b){
            return contents[b].score - contents[a].score;
        });
        catalog[g] = newlist.concat(watchedlist);
    };
    // History, Watching, Bookmark 생성
    watching = [];
    watching.removable = true;
    bookmark = [];
    var content;
    for(var id in contents){
        content = contents[id];
        if(content.bookmark) bookmark.push(id);
        if(content.pos && content.pos > 0) watching.push(id);
    }
    bookmark.sort(function(a, b){
        return contents[b].bookmark - contents[a].bookmark;
    });
    watching.sort(function(a, b){
        return contents[b].last - contents[a].last;
    });
    // Sentences 생성
    sentences = json.sentences;
    sentencesData = JSON.stringify(json.sentences);
    titles = json.titles;
    invalidate();
    progress.style.display='none';
}

function updateData(){
    var data = JSON.parse(window.home.getUpdateData()), item, id, j;
    var updated = data.contents;
    for(var i = updated.length - 1; i >= 0; i--){
        item = updated[i];
        id = item.id;
        contents[id] = item;
        j = _history.indexOf(id);
        if(j >= 0) _history.splice(j, 1);
        _history.unshift(id);

        j = watching.indexOf(id);
        if(j >= 0) watching.splice(j, 1);
        if(item.pos > 0){
            watching.unshift(id);
        }

        j = bookmark.indexOf(id);
        if(item.bookmark == 0 && j >= 0) bookmark.splice(j, 1);
        else if(item.bookmark > 0 && j == -1 ) bookmark.unshift(id);
        bookmark.sort(function(a, b){
            return contents[b].bookmark - contents[a].bookmark;
        });
    }
    updated = data.sentences;
    for(var i = updated.length - 1; i >= 0; i--){
        item = updated[i];
        var found = sentences.findIndex(function(elem){
            return elem.lang == item.lang && elem.id == item.id && elem.pos == item.pos
        })
        if(found >= 0) sentences.splice(found, 1);
        sentences.unshift(item)
    }
    invalidate();
}

function invalidate(){
    updateSentences();
    updateVideoList('catalog', catalog, true);
    updateVideoList('watching', {watching:watching}, true);
    updateVideoList('my', {bookmark:bookmark, history:_history}, true);
    historyDiv = document.getElementsByClassName('history')[0];
    historyDiv.onscroll = function(){
        ////console.log("offsetWidth + scrollLeft = "+(historyDiv.offsetWidth + Math.ceil(historyDiv.scrollLeft))+", scrollWidth = "+historyDiv.scrollWidth);
        if(historyDiv.offsetWidth + Math.ceil(historyDiv.scrollLeft) == historyDiv.scrollWidth){
            var last = historyDiv.lastChild.item.last;
            var json = JSON.parse(home.getHistoryList(last));
            if(json.history.length > 0){
                for(var id in json.contents){
                    contents[id] = json.contents[id];
                }
                _history = _history.concat(json.history);
                updateVideoList('my', {history:json.history});
            } else {
                historyDiv.onscroll = null;
            }
        }
    }
}

function updateVideoList(id, data, refresh){
    if(!data) return;
    div = document.getElementById(id);
    if(refresh)
        div.innerHTML = "";
    var keys = Object.keys(data), key, list, node, d, elem, n, cnt, k, g, id;
    var t = document.getElementById('template');
    for(var i =0; i < keys.length; i++){
        key = keys[i];
        list = data[key];
        if(list.length==0 && id=='watching') continue;
        if(refresh){
            node = document.createElement('h3');
            node.classList.add('category');
            g = groups[key];
            node.innerText = g!=null?g:key;
            div.append(node);
            d = document.createElement('div');
            d.classList.add('lt_cat');
            d.classList.add(key);
            d.list = list;
            d.key = key;
        } else {
            d = div.getElementsByClassName(key)[0];
        }
        if(list.length > 0){
            for(var j = 0; j < list.length; j++){
                elem = contents[list[j]];
                elem.id = list[j];
                ////console.log(elem.id+" / "+elem.title);
                node = document.createElement('div');
                node.classList = t.classList;
                node.innerHTML = t.innerHTML;
                k = elem.id.indexOf('_');
                node.type = elem.id.substring(0, k);
                node.vid = elem.id.substring(k+1);
                n = node.getElementsByClassName('lt_thumbnail')[0];
                img = new Image();
                img.onload = function(){
                  this.style.backgroundImage = "url('"+this.img.src+"')";
                }.bind({img:img, style:n.style});
                img.onerror = function(){
                  this.style.backgroundImage = "url('play.svg')";
                }.bind({img:img, style:n.style});
                if(node.type == 'yt'){
                  img.src = "https://i.ytimg.com/vi/"+node.vid+"/hqdefault.jpg"
                } else {
                    img.src = "file://"+IMAGE_FOLDER+'/'+encodeURI(elem.title)+".jpg"
                }
                ////console.log(n.style.backgroundImage);
                n.onclick = onItemClicked;
                if(elem.watched > 0){
                    n.children[0].innerText = formatSimpleDays(elem.last);
                    n.children[1].innerText = formatTimeString(elem.pos);
                } else {
                    n.children[0].style.display="none";
                    n.children[1].style.display="none";
                }
                n.children[2].innerText = formatTimeString(elem.duration);
                n = node.getElementsByClassName('lt_title')[0];
                n.innerText = elem.title;
                n.onclick = onItemClicked;
                // View Count 처리
                cnt = elem.watched?elem.watched:0;
                if(elem.views > 0) cnt += ' / '+minimizeNumber(elem.views);
                node.getElementsByClassName('lt_view_count')[0].innerText = cnt;
                // Bookmark 처리
                n = node.getElementsByClassName('lt_bookmark')[0];
                n.onclick=setFavorite;
                if(elem.bookmark){
                    n.classList.add('lt_bookmarked');
                }
                // Delete 처리
                if(list.removable){
                    n = node.getElementsByClassName('lt_delete')[0];
                    n.style.display = null;
                    n.onclick = onRemove
                }
                node.item = elem;
                d.append(node);
            }
        } else {
            d.innerHTML = '<div style="height:64px;"></div>';
        }
        if(refresh){
            div.append(d);
        }
    }
}
function updateSentences(){
    if(sentences.length > 0){
        updateSentence('notebook', titles["notebook"], sentences);
    }
    if(expressions.length == 0){
      expressions = JSON.parse(sentencesData);
    }
    var idx = Math.floor(Math.random()*expressions.length);
    updateSentence('today', null, expressions.splice(idx, 1), true);

}
function updateSentence(divId, title, list, disableDelete){
    var t = document.getElementById('sentence_template');
    var div = document.getElementById(divId);
    div.innerHTML = "";
    if(title){
        var node = document.createElement('h3');
        node.classList.add('category');
        node.innerText = title;
        div.append(node);
    }
    var d = document.createElement('div');
    d.classList.add('lt_cat');
    d.list = list;
    div.append(d);
    var elem, content, c, trans;
    for(var i in list){
        elem = list[i];
        content = contents[elem.id];
        elem.title = content.title;
        if(content.plist) elem.plist = content.plist;
        if(elem.desc){
          elem.trans += "<pre class='lt-sentence-desc'>"+elem.desc+"</pre>";
        }
        node = document.createElement('div');
        node.innerHTML = t.innerHTML;
        node.classList = t.classList;
        c = node.getElementsByClassName('lt-sentence-caption')[0];
        c.innerHTML = elem.caption;
        trans = node.getElementsByClassName('lt-sentence-main')[0].children[1];
        trans.onclick = showSentenceTranslation;
        trans.node = c;
        trans.elem = elem;
        trans.caption = true;
        var n = node.getElementsByClassName('lt-sentence-action')[0]
        n.onclick = onItemClicked;
        var k = elem.id.indexOf('_');
        n.type = elem.id.substring(0, k);
        n.vid = elem.id.substring(k+1);
        n.item = elem;
        if(n.type == 'yt'){
            n.children[0].src="https://i.ytimg.com/vi/"+n.vid+"/hqdefault.jpg"
        } else {
            n.children[0].src= "file://"+IMAGE_FOLDER+'/'+encodeURI(elem.title)+".jpg"
        }
        n.children[1].innerText = "["+formatTimeString(elem.pos)+"] "+elem.title;
        if(disableDelete){
            n.children[2].style.display = "none";
        } else {
            n.children[2].onclick = removeSentence;
        }
        d.append(node);
    }
}

function removeSentence(ev){
  ev.stopPropagation();
  var node = ev.srcElement.parentElement.parentElement;
  node.remove();
  var item = node.children[1].item;
  sentences.splice(sentences.indexOf(item), 1);
  home.removeSentence(item.lang, item.id, item.pos);
  return false;
}

function showSentenceTranslation(ev){
    this.node.innerHTML = this.caption?this.elem.trans:this.elem.caption;
    this.caption=!this.caption;
}

function formatTimeString(t){
    var s = "", m,sec;
    if(t>3600){
        s = Math.floor(t/3600)+':';
        t = t%3600;
    }
    m = t/60;
    sec = t%60;
    if(sec < 10) sec = "0"+sec;
    if(s.length > 0 && m < 10) s+="0";
    s += Math.floor(m)+':'+sec;
    return s;
}

function formatSimpleDays(t){
    var d = (Date.now() - t) / (1000*60*60*24);
    var l = navigator.language;
    var s;
    if(d < 1) s = getDaysPostfix(l, 0);
    else if(d < 2) s = getDaysPostfix(l, 1);
    else if(d < 7) s = Math.floor(d) + getDaysPostfix(l, 2);
    else if(d < 30) s = Math.floor(d/7) + getDaysPostfix(l, 3);
    else if(d < 365) s = Math.floor(d/30) + getDaysPostfix(l, 4);
    else s = Math.floor(d/365) + getDaysPostfix(l, 5);
    return s;
}

function getDaysPostfix(l, i){
    var d = daysPostfix[l];
    if(!d) d = daysPostfix['en'];
    return d[i];
}

var daysPostfix = {
    "en" : ["Today", "Yesterday", " days ago", " weeks ago", " months ago", " years ago"],
    "ko" : ["오늘", "어제", "일 전", "주 전", "개월 전", "년 전"],
}

function onItemClicked(event){
    var node = event.srcElement.parentElement;
    var url;
    var isYouTube = node.type=='yt';
    url = (isYouTube?'https://m.youtube.com/watch?v=':'file://')+node.vid;
    var item = node.item;
    if(item.pos > 0){
      var params = item.start >=0?("t="+item.start+"s&ltst="+item.pos):(params ="t="+item.pos+"s");
      url += (isYouTube?"&":"?")+params;
    }
    if(isYouTube && item.plist){
      url += "&list="+item.plist;
    }
    if(url) window.home.load(url, node.type+"_"+node.vid);
}

function setFavorite(event){
    var node = event.srcElement
    var item = node.parentElement.parentElement.item;
    if(node.classList.contains('lt_bookmarked')){
        item.bookmark = 0;
        bookmark.splice(bookmark.indexOf(item.id), 1);
        node.classList.remove('lt_bookmarked');
    } else {
        item.bookmark = Date.now();
        bookmark.unshift(item.id);
        node.classList.add('lt_bookmarked');
    }
    home.setFavorite(item.id, item.bookmark);
    invalidate();
}

function onRemove(event){
    var node = event.srcElement.parentElement.parentElement;
    var item = node.item;
    var list = node.parentElement.list;
    var key = node.parentElement.key;
    var i = list.indexOf(item.id);
    list.splice(i, 1);
    node.parentElement.removeChild(node);
    home.remove(key, item.id);
}

function minimizeNumber(n){
    if(n > 10000000000) return (n/1000000000).toFixed(0)+'B';
    else if(n > 450000000) return (n/1000000000).toFixed(1)+'B';
    if(n > 10000000) return (n/1000000).toFixed(0)+'M';
    else if(n > 450000) return (n/1000000).toFixed(1)+'M';
    else if(n > 10000)  return (n/1000).toFixed(0)+'K';
    else if(n > 450) return (n/1000).toFixed(1)+'K';
    else return n;
}

function show(type){
    if(type=='catalog'){
        document.getElementById('today').style.display=null;
        document.getElementById('watching').style.display=null;
        document.getElementById('catalog').style.display=null;
        document.getElementById('my').style.display='none';
        document.getElementById('notebook').style.display='none';
    } else if(type=='my'){
        document.getElementById('today').style.display='none';
        document.getElementById('catalog').style.display='none';
        document.getElementById('watching').style.display='none';
        document.getElementById('my').style.display=null;
        document.getElementById('notebook').style.display=null;
    }
    scrollTo(0,0);
}

function checkAndLoad(){
    //console.log("checkAndLoad() "+window.home.isReadyToLoad());
    if(window.home.isReadyToLoad()) loadData();
    else setTimeout(checkAndLoad, 500);
}

window.WebHome = function(){
    //@interface
    this.load = function(url){
        window.location.href=url;
    };
    //@interface
    this.getCatalog = function(){
        return JSON.stringify(window.home.data);
    };
    //@interface
    this.getUpdateData = function(){
        return JSON.stringify(window.home.updated);
    };
    //@interface
    this.setLike = function(cid, like){
        //console.log('  home.setLike() '+cid+', '+like);
    };
    //@interface
    this.setFavorite = function(cid, bookmark){
        //console.log('  home.setFavorite() '+cid+', '+bookmark);
    };
    //@interface
    this.getHistoryList = function(last){
        return historyTest[historyCnt++];
    };
    //@interface
    this.remove = function(key, id){
        //console.log("  home.remove() key="+key+", id="+id);
    }
    //@interface
    this.removeSentence = function(lang, id, pos){
        //console.log("  home.removeSentence() lang="+lang+", id="+id+", pos="+pos);
    }
    historyTest = ['{"history":["yt_xpjD_YeBERQ","yt_w4gPu5Tv0ts","yt_arj7oStGLkU"],"contents":{}}', '{"history":[],"contents":{}}']
    historyCnt = 0;

    {
        // 테스트용 카달로그 로딩
        var url = window.location.href;
        var i = url.indexOf('l=')+2;
        var l = (i>10)?url.substring(i, i+2):'en';
        var s = document.createElement('script');
        s.type = 'text/javascript';
        s.src = 'dummy_'+l+'.js';
        document.body.appendChild(s);
    }
    return this;
}

window.onload = function(){
  if(location.href.includes("rtl")) document.body.dir="rtl";
  if(!window.home){
      window.home = new WebHome();
      setTimeout(loadData, 500);
  } else checkAndLoad();
}